﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Homework_Week03
{
    public partial class Form1 : Form
    {
        List<string> Username = new List<string>();
        List<string> password = new List<string>();
        List<int> Saldo = new List<int>();
        int akun;
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Register_Click(object sender, EventArgs e)
        {
            panel_Menu.Visible = false;
            panel_Register.Visible = true;
            tb_Username.Clear();
            tb_Password.Clear();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            int count = 0;
            bool Password = false;
            akun = 0;
            foreach (string x in Username)
            {
                if (tb_Username.Text == x)
                {
                    akun = count;
                    Password = true;
                }
                count++;
            }
            if (Password == false)
            {
                MessageBox.Show("Error");
                return;
            }
            else
            {
                if (password[akun] != tb_Password.Text)
                {
                    Password = false;
                    MessageBox.Show("password salah");
                }
            }
            if (Password == true)
            {
                MessageBox.Show("Selamat datang" + " " + tb_Username.Text);
                panel_Menu.Visible = false;
                panel_Register.Visible = false;
                panel_Balance.Visible = true;
                string saldo = Saldo[akun].ToString("N0");
                label_Balance.Text = "Rp. " + saldo + ",00";
                tb_Username.Clear();
                tb_Password.Clear();
            }
        }

        private void btn_Register2_Click(object sender, EventArgs e)
        {
            if (Username.Contains(tb_Username2.Text))
            {
                MessageBox.Show("akun sudah ada! Input ulang");
                tb_Username2.Clear();
                tb_Password2.Clear();
                return;
            }
            else
            {
                Username.Add(tb_Username2.Text);
                password.Add(tb_Password2.Text);
                Saldo.Add(0);
                panel_Register.Visible = false;
                panel_Menu.Visible = true;
                tb_Username2.Clear();
                tb_Password2.Clear();
                MessageBox.Show("akun berhasil terdaftar");
            }
        }

        private void btn_Deposit_Click(object sender, EventArgs e)
        {
            panel_Balance.Visible = false;
            panel_Deposit.Visible = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel_Menu.Top = 60;
            panel_Register.Top = 60;
            panel_Balance.Top = 60;
            panel_Deposit.Top = 60;
            panel_Withdraw.Top = 60;
            BackColor = Color.AliceBlue;
        }

        private void btn_Logout_Click(object sender, EventArgs e)
        {
            panel_Withdraw.Visible = false;
            panel_Balance.Visible = false;
            panel_Register.Visible = false;
            panel_Deposit.Visible = false;
            panel_Menu.Visible = true;
        }

        private void btn_Setor_Click(object sender, EventArgs e)
        {
            panel_Deposit.Visible = false;
            panel_Balance.Visible = true;
            string deposits = tb_Deposit.Text.Replace(".", "");
            if (int.TryParse(deposits, out int number))
            {
                int deposit = Convert.ToInt32(deposits);
                if (deposit <= 0)
                {
                    MessageBox.Show("Uang tidak cukup");
                }
                else
                {
                    Saldo[akun] = Saldo[akun] + deposit;
                    MessageBox.Show("berhasil setor uang Rp." + deposit.ToString("N0") + ",00");
                    tb_Deposit.Clear();
                    label_Balance.Text = "Rp." + Saldo[akun].ToString("N0") + ",00";
                }
            }
            else
            {
                MessageBox.Show("Input Error");
            }
        }

        private void btn_Logout2_Click(object sender, EventArgs e)
        {
            panel_Withdraw.Visible = false;
            panel_Balance.Visible = false;
            panel_Register.Visible = false;
            panel_Deposit.Visible = false;
            panel_Menu.Visible = true;
        }

        private void btn_Logout3_Click(object sender, EventArgs e)
        {
            panel_Withdraw.Visible = false;
            panel_Balance.Visible = false;
            panel_Register.Visible = false;
            panel_Deposit.Visible = false;
            panel_Menu.Visible = true;
        }

        private void btn_Withdraw_Click(object sender, EventArgs e)
        {
            panel_Withdraw.Visible = true;
            panel_Balance.Visible = false;
        }

        private void btn_Withdraw2_Click(object sender, EventArgs e)
        {
            panel_Withdraw.Visible = false;
            panel_Balance.Visible = true;
            string tbwithdraw = tb_Withdraw.Text.Replace(".", "");
            if (int.TryParse(tbwithdraw, out int number))
            {
                int withdraw = Convert.ToInt32(tbwithdraw);
                if (Saldo[akun] >= withdraw)
                {
                    Saldo[akun] = Saldo[akun] - withdraw;
                    MessageBox.Show("sukses tarik Rp." + withdraw.ToString("N0") + ",00");
                    tb_Withdraw.Clear();
                    label_Balance.Text = "Rp." + Saldo[akun].ToString("N0") + ",00";
                }
                else
                {
                    MessageBox.Show("Saldo tidak cukup");
                }
            }
            else
            {
                MessageBox.Show("Error");
            }

        }
    }
}

 



