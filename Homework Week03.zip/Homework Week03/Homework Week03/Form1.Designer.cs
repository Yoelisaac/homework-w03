﻿namespace Homework_Week03
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_Username = new System.Windows.Forms.TextBox();
            this.tb_Password = new System.Windows.Forms.TextBox();
            this.txt_Username = new System.Windows.Forms.Label();
            this.txt_Password = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_Register = new System.Windows.Forms.Button();
            this.btn_login = new System.Windows.Forms.Button();
            this.panel_Menu = new System.Windows.Forms.Panel();
            this.panel_Register = new System.Windows.Forms.Panel();
            this.btn_Register2 = new System.Windows.Forms.Button();
            this.tb_Password2 = new System.Windows.Forms.TextBox();
            this.tb_Username2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel_Balance = new System.Windows.Forms.Panel();
            this.label_Balance = new System.Windows.Forms.Label();
            this.btn_Withdraw = new System.Windows.Forms.Button();
            this.btn_Deposit = new System.Windows.Forms.Button();
            this.btn_Logout = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel_Deposit = new System.Windows.Forms.Panel();
            this.tb_Deposit = new System.Windows.Forms.TextBox();
            this.btn_Logout2 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.btn_Setor = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.panel_Withdraw = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.tb_Withdraw = new System.Windows.Forms.TextBox();
            this.btn_Logout3 = new System.Windows.Forms.Button();
            this.btn_Withdraw2 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.panel_Menu.SuspendLayout();
            this.panel_Register.SuspendLayout();
            this.panel_Balance.SuspendLayout();
            this.panel_Deposit.SuspendLayout();
            this.panel_Withdraw.SuspendLayout();
            this.SuspendLayout();
            // 
            // tb_Username
            // 
            this.tb_Username.Location = new System.Drawing.Point(91, 64);
            this.tb_Username.Name = "tb_Username";
            this.tb_Username.Size = new System.Drawing.Size(100, 20);
            this.tb_Username.TabIndex = 0;
            // 
            // tb_Password
            // 
            this.tb_Password.Location = new System.Drawing.Point(91, 96);
            this.tb_Password.Name = "tb_Password";
            this.tb_Password.Size = new System.Drawing.Size(100, 20);
            this.tb_Password.TabIndex = 1;
            // 
            // txt_Username
            // 
            this.txt_Username.AutoSize = true;
            this.txt_Username.Location = new System.Drawing.Point(28, 67);
            this.txt_Username.Name = "txt_Username";
            this.txt_Username.Size = new System.Drawing.Size(55, 13);
            this.txt_Username.TabIndex = 2;
            this.txt_Username.Text = "Username";
            // 
            // txt_Password
            // 
            this.txt_Password.AutoSize = true;
            this.txt_Password.Location = new System.Drawing.Point(28, 99);
            this.txt_Password.Name = "txt_Password";
            this.txt_Password.Size = new System.Drawing.Size(53, 13);
            this.txt_Password.TabIndex = 3;
            this.txt_Password.Text = "Password";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(52, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 29);
            this.label3.TabIndex = 4;
            this.label3.Text = "UC Bank";
            // 
            // btn_Register
            // 
            this.btn_Register.Location = new System.Drawing.Point(91, 177);
            this.btn_Register.Name = "btn_Register";
            this.btn_Register.Size = new System.Drawing.Size(75, 23);
            this.btn_Register.TabIndex = 5;
            this.btn_Register.Text = "Register";
            this.btn_Register.UseVisualStyleBackColor = true;
            this.btn_Register.Click += new System.EventHandler(this.btn_Register_Click);
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(70, 149);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(75, 23);
            this.btn_login.TabIndex = 6;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // panel_Menu
            // 
            this.panel_Menu.Controls.Add(this.btn_login);
            this.panel_Menu.Location = new System.Drawing.Point(21, -1);
            this.panel_Menu.Name = "panel_Menu";
            this.panel_Menu.Size = new System.Drawing.Size(189, 212);
            this.panel_Menu.TabIndex = 7;
            // 
            // panel_Register
            // 
            this.panel_Register.Controls.Add(this.btn_Register2);
            this.panel_Register.Controls.Add(this.tb_Password2);
            this.panel_Register.Controls.Add(this.tb_Username2);
            this.panel_Register.Controls.Add(this.label6);
            this.panel_Register.Controls.Add(this.label5);
            this.panel_Register.Controls.Add(this.label4);
            this.panel_Register.Location = new System.Drawing.Point(239, -1);
            this.panel_Register.Name = "panel_Register";
            this.panel_Register.Size = new System.Drawing.Size(189, 212);
            this.panel_Register.TabIndex = 8;
            this.panel_Register.Visible = false;
            // 
            // btn_Register2
            // 
            this.btn_Register2.Location = new System.Drawing.Point(73, 152);
            this.btn_Register2.Name = "btn_Register2";
            this.btn_Register2.Size = new System.Drawing.Size(75, 23);
            this.btn_Register2.TabIndex = 11;
            this.btn_Register2.Text = "Register";
            this.btn_Register2.UseVisualStyleBackColor = true;
            this.btn_Register2.Click += new System.EventHandler(this.btn_Register2_Click);
            // 
            // tb_Password2
            // 
            this.tb_Password2.Location = new System.Drawing.Point(73, 97);
            this.tb_Password2.Name = "tb_Password2";
            this.tb_Password2.Size = new System.Drawing.Size(100, 20);
            this.tb_Password2.TabIndex = 9;
            // 
            // tb_Username2
            // 
            this.tb_Username2.Location = new System.Drawing.Point(73, 65);
            this.tb_Username2.Name = "tb_Username2";
            this.tb_Username2.Size = new System.Drawing.Size(100, 20);
            this.tb_Username2.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 104);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Password";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 72);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Username";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(40, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 29);
            this.label4.TabIndex = 5;
            this.label4.Text = "UC Bank";
            // 
            // panel_Balance
            // 
            this.panel_Balance.Controls.Add(this.label_Balance);
            this.panel_Balance.Controls.Add(this.btn_Withdraw);
            this.panel_Balance.Controls.Add(this.btn_Deposit);
            this.panel_Balance.Controls.Add(this.btn_Logout);
            this.panel_Balance.Controls.Add(this.label7);
            this.panel_Balance.Controls.Add(this.label9);
            this.panel_Balance.Location = new System.Drawing.Point(463, -1);
            this.panel_Balance.Name = "panel_Balance";
            this.panel_Balance.Size = new System.Drawing.Size(189, 212);
            this.panel_Balance.TabIndex = 9;
            this.panel_Balance.Visible = false;
            // 
            // label_Balance
            // 
            this.label_Balance.AutoSize = true;
            this.label_Balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Balance.Location = new System.Drawing.Point(65, 100);
            this.label_Balance.Name = "label_Balance";
            this.label_Balance.Size = new System.Drawing.Size(42, 20);
            this.label_Balance.TabIndex = 14;
            this.label_Balance.Text = "Rp0";
            // 
            // btn_Withdraw
            // 
            this.btn_Withdraw.Location = new System.Drawing.Point(57, 178);
            this.btn_Withdraw.Name = "btn_Withdraw";
            this.btn_Withdraw.Size = new System.Drawing.Size(75, 23);
            this.btn_Withdraw.TabIndex = 13;
            this.btn_Withdraw.Text = "Withdraw";
            this.btn_Withdraw.UseVisualStyleBackColor = true;
            this.btn_Withdraw.Click += new System.EventHandler(this.btn_Withdraw_Click);
            // 
            // btn_Deposit
            // 
            this.btn_Deposit.Location = new System.Drawing.Point(57, 149);
            this.btn_Deposit.Name = "btn_Deposit";
            this.btn_Deposit.Size = new System.Drawing.Size(75, 23);
            this.btn_Deposit.TabIndex = 12;
            this.btn_Deposit.Text = "Deposit";
            this.btn_Deposit.UseVisualStyleBackColor = true;
            this.btn_Deposit.Click += new System.EventHandler(this.btn_Deposit_Click);
            // 
            // btn_Logout
            // 
            this.btn_Logout.Location = new System.Drawing.Point(57, 58);
            this.btn_Logout.Name = "btn_Logout";
            this.btn_Logout.Size = new System.Drawing.Size(75, 23);
            this.btn_Logout.TabIndex = 11;
            this.btn_Logout.Text = "Logout";
            this.btn_Logout.UseVisualStyleBackColor = true;
            this.btn_Logout.Click += new System.EventHandler(this.btn_Logout_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 104);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Balance: ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(40, 10);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(114, 29);
            this.label9.TabIndex = 5;
            this.label9.Text = "UC Bank";
            // 
            // panel_Deposit
            // 
            this.panel_Deposit.Controls.Add(this.tb_Deposit);
            this.panel_Deposit.Controls.Add(this.btn_Logout2);
            this.panel_Deposit.Controls.Add(this.label10);
            this.panel_Deposit.Controls.Add(this.btn_Setor);
            this.panel_Deposit.Controls.Add(this.label12);
            this.panel_Deposit.Location = new System.Drawing.Point(134, 229);
            this.panel_Deposit.Name = "panel_Deposit";
            this.panel_Deposit.Size = new System.Drawing.Size(189, 212);
            this.panel_Deposit.TabIndex = 10;
            this.panel_Deposit.Visible = false;
            // 
            // tb_Deposit
            // 
            this.tb_Deposit.Location = new System.Drawing.Point(45, 114);
            this.tb_Deposit.Name = "tb_Deposit";
            this.tb_Deposit.Size = new System.Drawing.Size(109, 20);
            this.tb_Deposit.TabIndex = 11;
            // 
            // btn_Logout2
            // 
            this.btn_Logout2.Location = new System.Drawing.Point(57, 53);
            this.btn_Logout2.Name = "btn_Logout2";
            this.btn_Logout2.Size = new System.Drawing.Size(75, 23);
            this.btn_Logout2.TabIndex = 15;
            this.btn_Logout2.Text = "Logout";
            this.btn_Logout2.UseVisualStyleBackColor = true;
            this.btn_Logout2.Click += new System.EventHandler(this.btn_Logout2_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(42, 93);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(112, 13);
            this.label10.TabIndex = 14;
            this.label10.Text = "Input Deposit Amount:";
            // 
            // btn_Setor
            // 
            this.btn_Setor.Location = new System.Drawing.Point(57, 157);
            this.btn_Setor.Name = "btn_Setor";
            this.btn_Setor.Size = new System.Drawing.Size(75, 23);
            this.btn_Setor.TabIndex = 12;
            this.btn_Setor.Text = "Deposit";
            this.btn_Setor.UseVisualStyleBackColor = true;
            this.btn_Setor.Click += new System.EventHandler(this.btn_Setor_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(40, 10);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(114, 29);
            this.label12.TabIndex = 5;
            this.label12.Text = "UC Bank";
            // 
            // panel_Withdraw
            // 
            this.panel_Withdraw.Controls.Add(this.label15);
            this.panel_Withdraw.Controls.Add(this.tb_Withdraw);
            this.panel_Withdraw.Controls.Add(this.btn_Logout3);
            this.panel_Withdraw.Controls.Add(this.btn_Withdraw2);
            this.panel_Withdraw.Controls.Add(this.label13);
            this.panel_Withdraw.Location = new System.Drawing.Point(368, 229);
            this.panel_Withdraw.Name = "panel_Withdraw";
            this.panel_Withdraw.Size = new System.Drawing.Size(189, 212);
            this.panel_Withdraw.TabIndex = 11;
            this.panel_Withdraw.Visible = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(33, 93);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(121, 13);
            this.label15.TabIndex = 17;
            this.label15.Text = "Input Withdraw Amount:";
            // 
            // tb_Withdraw
            // 
            this.tb_Withdraw.Location = new System.Drawing.Point(36, 114);
            this.tb_Withdraw.Name = "tb_Withdraw";
            this.tb_Withdraw.Size = new System.Drawing.Size(109, 20);
            this.tb_Withdraw.TabIndex = 11;
            // 
            // btn_Logout3
            // 
            this.btn_Logout3.Location = new System.Drawing.Point(57, 53);
            this.btn_Logout3.Name = "btn_Logout3";
            this.btn_Logout3.Size = new System.Drawing.Size(75, 23);
            this.btn_Logout3.TabIndex = 15;
            this.btn_Logout3.Text = "Logout";
            this.btn_Logout3.UseVisualStyleBackColor = true;
            this.btn_Logout3.Click += new System.EventHandler(this.btn_Logout3_Click);
            // 
            // btn_Withdraw2
            // 
            this.btn_Withdraw2.Location = new System.Drawing.Point(57, 157);
            this.btn_Withdraw2.Name = "btn_Withdraw2";
            this.btn_Withdraw2.Size = new System.Drawing.Size(75, 23);
            this.btn_Withdraw2.TabIndex = 12;
            this.btn_Withdraw2.Text = "Withdraw";
            this.btn_Withdraw2.UseVisualStyleBackColor = true;
            this.btn_Withdraw2.Click += new System.EventHandler(this.btn_Withdraw2_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(40, 10);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(114, 29);
            this.label13.TabIndex = 5;
            this.label13.Text = "UC Bank";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(910, 453);
            this.Controls.Add(this.panel_Withdraw);
            this.Controls.Add(this.panel_Deposit);
            this.Controls.Add(this.panel_Balance);
            this.Controls.Add(this.panel_Register);
            this.Controls.Add(this.btn_Register);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_Password);
            this.Controls.Add(this.txt_Username);
            this.Controls.Add(this.tb_Password);
            this.Controls.Add(this.tb_Username);
            this.Controls.Add(this.panel_Menu);
            this.Name = "Form1";
            this.Text = "v";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel_Menu.ResumeLayout(false);
            this.panel_Register.ResumeLayout(false);
            this.panel_Register.PerformLayout();
            this.panel_Balance.ResumeLayout(false);
            this.panel_Balance.PerformLayout();
            this.panel_Deposit.ResumeLayout(false);
            this.panel_Deposit.PerformLayout();
            this.panel_Withdraw.ResumeLayout(false);
            this.panel_Withdraw.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_Username;
        private System.Windows.Forms.TextBox tb_Password;
        private System.Windows.Forms.Label txt_Username;
        private System.Windows.Forms.Label txt_Password;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_Register;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Panel panel_Menu;
        private System.Windows.Forms.Panel panel_Register;
        private System.Windows.Forms.Button btn_Register2;
        private System.Windows.Forms.TextBox tb_Password2;
        private System.Windows.Forms.TextBox tb_Username2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel_Balance;
        private System.Windows.Forms.Button btn_Logout;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btn_Withdraw;
        private System.Windows.Forms.Button btn_Deposit;
        private System.Windows.Forms.Label label_Balance;
        private System.Windows.Forms.Panel panel_Deposit;
        private System.Windows.Forms.TextBox tb_Deposit;
        private System.Windows.Forms.Button btn_Logout2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btn_Setor;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel_Withdraw;
        private System.Windows.Forms.TextBox tb_Withdraw;
        private System.Windows.Forms.Button btn_Logout3;
        private System.Windows.Forms.Button btn_Withdraw2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
    }
}

